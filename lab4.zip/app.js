let express = require('express');
let app = express();

//Setup the view Engine
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');
//Setup the static assets directories
app.use(express.static('images'));
app.use(express.static('css'));
//parse application json
app.use(express.urlencoded({extended: true}));
app.use(express.json())

// db
let db = [];
let rec = {};
rec = {
    title:"Monash",
    author:"Jonh Monash",
    topic:"University",
    cost:100,
};
db.push(rec);

//page

app.get('/', function (req, res) {
    res.render('index');
});

app.get('/:page',function(req,res){
    switch(req.params.page){
        case 'addbooks':
            res.render('addbooks');
            break;
        case 'listbooks':
            res.render('listbooks',{bookdb:db});
            break;
        default:
            res.render('404');
            break;
    }
})

//data operation

app.post('/:func',function(req,res){
    switch(req.params.func){
        case 'data':
            if(req.body.title.length < 3 || req.body.author.length < 3 || req.body.cost < 0){
                res.render('invalid');
                break;
            }else{
                let newRec = {
                    title:req.body.title,
                    author:req.body.author,
                    topic:req.body.topic,
                    cost:req.body.cost,
                };
                db.push(newRec);
                res.render('addbooks');
                break;
            }
    }
})




app.listen(8080);